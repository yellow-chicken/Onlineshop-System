window.onload = function(){
	//用户名验证
	//获取span标签
	var usernameErrorSpan = document.getElementById("usernameError");
	//用户名绑定blur
	var usernameElt = document.getElementById("username");
	usernameElt.onblur = function(){
		//获取用户名
		var username = usernameElt.value;
		//去除空白
		username = username.trim();
		//判断用户名是否为空
		if(username.length == 0){
			//用户名为空
			usernameErrorSpan.innerText = "用户名不能为空!";
		}else{
			//用户名不为空
			if(username.length < 6 || username.length > 14){
				//用户名长度非法
				usernameErrorSpan.innerText = "用户名长度必须在6~14之间!";
			}else{
				//用户名长度合法
				//判断是否含有特殊符号
				var regExp = /^[A-Za-z0-9]+$/;
				if(regExp.test(username)){
					//用户名最终合法
				}else{
					//用户名含有特殊符号
					usernameErrorSpan.innerText = "用户名只能由数字和字母组成!";
				}
			}
		}
	}

	usernameElt.onfocus = function(){
		//清空非法value
		//span有字就是不合法
		if(usernameErrorSpan.innerText != ""){
			usernameElt.value = "";
		}
		//清空span，移到下面
		usernameErrorSpan.innerText = "";
	}

	//密码验证
	var pwdErrorSpan = document.getElementById("pwdError");
	var confirmPwdErrorSpan = document.getElementById("confirmPwdError");
	var confirmPwdElt = document.getElementById("confirmPwd");
	var pwdElt = document.getElementById("pwd");



	pwdElt.onblur = function(){
		var pwd = pwdElt.value;
		if(pwd.length == 0){
			//密码框为空
			pwdErrorSpan.innerText = "密码不能为空!";
		}else{
			//密码框不为空
		}
	}

	confirmPwdElt.onblur = function(){
		//获取密码和确认密码
		var pwd = pwdElt.value;
		var confirmPwd = confirmPwdElt.value;
		if(confirmPwd.length == 0){
			//确认密码框为空
			confirmPwdErrorSpan.innerText = "确认密码不能为空!";
		}else{
			if(pwd != confirmPwd){
				//密码不一致
				confirmPwdErrorSpan.innerText = "密码不一致!";
			}else{
				//密码一致
			}
		}
	}


	confirmPwdElt.onfocus = function(){
		if(confirmPwdErrorSpan.innerText != ""){
			confirmPwdElt.value = "";
		}
		//清空span，移到下面
		confirmPwdErrorSpan.innerText = "";
	}

	pwdElt.onfocus = function(){
		if(pwdErrorSpan.innerText != ""){
			pwdElt.value = "";
		}
		//清空span，移到下面
		pwdErrorSpan.innerText = "";
	}

	//姓名验证
	var nameErrorSpan = document.getElementById("nameError");
	var nameElt = document.getElementById("name");
	nameElt.onblur = function(){
		var name = nameElt.value;
		name = name.trim();
		var nameRegExp =  /^[\u4E00-\u9FA5A-Za-z]+$/;
		if(nameRegExp.test(name)){
			//合法
		}else{
			//不合法
			nameErrorSpan.innerText = "姓名不合法!"
		}
	}

	nameElt.onfocus = function(){
		if(nameErrorSpan.innerText != ""){
			nameElt.value = "";
		}
		nameErrorSpan.innerText = "";
	}

	//电话号码验证
	var telErrorSpan = document.getElementById("telError");
	var telElt = document.getElementById("tel");
	telElt.onblur = function(){
		var tel = telElt.value;
		tel = tel.trim();
		var telRegExp = /^1[3456789]\d{9}$/;
		if(telRegExp.test(tel)){
			//合法
		}else{
			//不合法
			telErrorSpan.innerText = "电话号码不合法!"
		}
	}

	telElt.onfocus = function(){
		if(telErrorSpan.innerText != ""){
			telElt.value = "";
		}
		telErrorSpan.innerText = "";
	}

	//给button按钮绑定鼠标单击事件
	var submitBtnElt = document.getElementById("register");
	submitBtnElt.onclick = function(){
		//触发username、confirmPwd、tel的blur 不需要人工操作，使用js代码触发事件
		usernameElt.focus();
		usernameElt.blur();

		pwdElt.focus();
		pwdElt.blur();

		confirmPwdElt.focus();
		confirmPwdElt.blur();

		nameElt.focus();
		nameElt.blur();

		telElt.focus();
		telElt.blur();
		//所有表单项合法才可以提交
		if(usernameErrorSpan.innerText == "" &&  confirmPwdErrorSpan.innerText == "" &&  nameErrorSpan.innerText == "" && telErrorSpan.innerText == ""){
			//获取表单对象
			var userFormElt = document.getElementById("userform");
			//提交表单
			userFormElt.submit();
		}
	}
}