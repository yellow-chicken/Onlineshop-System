window.onload = function(){
    //密码验证
    var originalPwdElt = document.getElementById("pwd0");
    var originalPwdErrorSpan = document.getElementById("pwd0Error");

    var pwdElt = document.getElementById("pwd");
    var pwdErrorSpan = document.getElementById("pwdError");

    var confirmPwdElt = document.getElementById("confirmPwd");
    var confirmPwdErrorSpan = document.getElementById("confirmPwdError");

    originalPwdElt.onblur = function(){
        var originalPwd = originalPwdElt.value;
        if(originalPwd.length == 0){
            //密码框为空
            originalPwdErrorSpan.innerText = "新密码不能为空!";
        }else{
            //密码框不为空
        }
    }

    originalPwdElt.onfocus = function(){
        if(originalPwdErrorSpan.innerText != ""){
            originalPwdElt.value = "";
        }
        //清空span，移到下面
        originalPwdErrorSpan.innerText = "";
    }

    pwdElt.onblur = function(){
        var originalPwd = originalPwdElt.value;
        var pwd = pwdElt.value;
        if(pwd.length == 0){
            //密码框为空
            pwdErrorSpan.innerText = "新密码不能为空!";
        }else{
            //密码框不为空
            if(originalPwd == pwd){
                pwdErrorSpan.innerText = "新密码与旧密码不能相同!";
            }
        }
    }

    confirmPwdElt.onblur = function(){
        //获取密码和确认密码
        var originalPwd = originalPwdElt.value;
        var pwd = pwdElt.value;
        var confirmPwd = confirmPwdElt.value;

        if(confirmPwd.length == 0){
            //确认密码框为空
            confirmPwdErrorSpan.innerText = "确认密码不能为空!";
        }else {
            if(pwd != confirmPwd){
                //密码不一致
                confirmPwdErrorSpan.innerText = "密码不一致!";
            }else{
                //密码一致
            }
        }
    }


    confirmPwdElt.onfocus = function(){
        if(confirmPwdErrorSpan.innerText != ""){
            confirmPwdElt.value = "";
        }
        //清空span，移到下面
        confirmPwdErrorSpan.innerText = "";
    }

    pwdElt.onfocus = function(){
        if(pwdErrorSpan.innerText != ""){
            pwdElt.value = "";
        }
        //清空span，移到下面
        pwdErrorSpan.innerText = "";
    }


    //给button按钮绑定鼠标单击事件
    var submitBtnElt = document.getElementById("changePwd");
    submitBtnElt.onclick = function(){

        originalPwdElt.focus();
        originalPwdElt.blur();
        
        pwdElt.focus();
        pwdElt.blur();

        confirmPwdElt.focus();
        confirmPwdElt.blur();

        //所有表单项合法才可以提交
        if(confirmPwdErrorSpan.innerText == ""){
            //获取表单对象
            var userFormElt = document.getElementById("changePwdform");
            //提交表单
            userFormElt.submit();
        }
    }
}