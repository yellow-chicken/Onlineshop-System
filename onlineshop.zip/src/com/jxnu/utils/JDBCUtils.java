package com.jxnu.utils;

import java.sql.*;

/**
 * 连接数据库工具类
 */
public class JDBCUtils {
    //工具类中的构造方法全为private，因为工具类的方法都是静态的，直接用类名调用，不需要new对象，为了防止别人new对象则写为private
    private JDBCUtils() { }

    //注册驱动只执行一次，静态代码块在类加载的时候执行并且只执行一次
    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取数据库连接对象
     * @return 连接对象
     * @throws SQLException
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/onlineshop?useUnicode=true&characterEncoding=utf8","root","root");
    }

    //引入Statement是因为PreparedStatement是其子类，可以用多态传进去

    /**
     * 关闭资源
     * @param conn 连接对象
     * @param ps 数据库操作对象
     * @param rs 结果集
     */
    public static void close(Connection conn, Statement ps, ResultSet rs) {
        if (rs !=null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (ps != null) {
            try {
                ps.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

