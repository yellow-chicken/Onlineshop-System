package com.jxnu.servlet;

import com.jxnu.service.CustomerOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class CusChangeAddrServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out=response.getWriter();

        String username = (String)request.getSession().getAttribute("username");
        String addr = request.getParameter("addr");
        CustomerOperation CusOp = new CustomerOperation();
        CusOp.changeAddr(username,addr);
        out.print("<script>alert('保存成功');window.location.href='customerChangeAddr.jsp'</script>");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
