package com.jxnu.servlet;

import com.jxnu.bean.Company;
import com.jxnu.bean.LoginInfo;
import com.jxnu.service.RegisterOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class ComRegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String identity = request.getParameter("identity");
        String name = request.getParameter("name");
        String tel = request.getParameter("tel");

        RegisterOperation regO = new RegisterOperation();
        if (!regO.isUnameExist(username)) {
            if(!regO.comNameIsExist(name)) {
                if (!regO.cusTelIsExist(tel) && !regO.busTelIsExist(tel) && !regO.comTelIsExist(tel)) {
                    Company company = new Company();

                    company.setUsername(username);
                    company.setName(name);
                    company.setTel(tel);
                    regO.registerCompany(company);

                    LoginInfo loginInfo = new LoginInfo();

                    loginInfo.setUsername(username);
                    loginInfo.setPassword(password);
                    loginInfo.setIdentity(identity);

                    regO.addTologin(loginInfo);
                    out.print("<script>alert('注册成功！');window.location.href='index.jsp'</script>");
                }else{
                    out.print("<script>alert('此号码已被注册！');window.location.href='registerCompany.jsp'</script>");
                }
            } else {
                out.print("<script>alert('此公司名已被注册！');window.location.href='registerCompany.jsp'</script>");
            }

        } else{
            out.print("<script>alert('此用户名已被注册！');window.location.href='registerCompany.jsp'</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
