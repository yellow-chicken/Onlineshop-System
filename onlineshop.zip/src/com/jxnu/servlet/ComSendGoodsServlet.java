package com.jxnu.servlet;

import com.jxnu.service.OrderOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class ComSendGoodsServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out=response.getWriter();

        String orderNum = request.getParameter("orderNum");
        String status = request.getParameter("status");

        OrderOperation OrdOp = new OrderOperation();
        if ("已出货".equals(status)){
            OrdOp.ComSendGoods(orderNum);
            out.print("<script>alert('已接单，仓库正在出货...');window.location.href='companyOrderHandle.jsp'</script>");
        } else if ("退货中".equals(status)){
            OrdOp.ComReturnGoods(orderNum);
            out.print("<script>alert('已接单，仓库正在出货...');window.location.href='companyOrderHandle.jsp'</script>");
        }else if ("已退货".equals(status)){
            out.print("<script>alert('此订单已退货，请勿做任何操作！');window.location.href='companyOrderHandle.jsp'</script>");
        }else if ("已收货".equals(status)) {
            out.print("<script>alert('此订单已结单！');window.location.href='companyOrderHandle.jsp'</script>");
        } else {
            out.print("<script>alert('此订单已出货，请勿重复发货！');window.location.href='companyOrderHandle.jsp'</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
