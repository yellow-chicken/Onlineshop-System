package com.jxnu.servlet;

import com.jxnu.service.LoginOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class UserCheckServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String identity = request.getParameter("identity");

        request.getSession().setAttribute("username",username);
        request.getSession().setAttribute("identity",identity);

        LoginOperation loginOperation = new LoginOperation();
        boolean loginInfo = loginOperation.login(username, password, identity);
        if (loginInfo && "customer".equals(identity)) {
            response.sendRedirect("customerBuyGoods.jsp");
        } else if(loginInfo && "business".equals(identity)) {
            response.sendRedirect("businessOrderHandle.jsp");
        } else if(loginInfo && "company".equals(identity)) {
            response.sendRedirect("companyOrderHandle.jsp");
        } else {
            if (request.getParameter("username") == "") {
                request.setAttribute("msg","请输入用户名");
                request.getRequestDispatcher("index.jsp").forward(request,response);
            } else if (request.getParameter("password") == "") {
                request.setAttribute("msg","请输入密码");
                request.setAttribute("username",username);
                request.getRequestDispatcher("index.jsp").forward(request,response);
            } else if (request.getParameter("identity") == null) {
                request.setAttribute("msg","请选择用户类型");
                request.setAttribute("username",username);
                request.setAttribute("password",password);
                request.getRequestDispatcher("index.jsp").forward(request,response);
            } else{
                request.setAttribute("msg","用户名或密码或用户类型错误");
                request.getRequestDispatcher("index.jsp").forward(request,response);
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
