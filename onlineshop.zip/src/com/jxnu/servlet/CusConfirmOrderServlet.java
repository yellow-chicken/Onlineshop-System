package com.jxnu.servlet;

import com.jxnu.service.OrderOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class CusConfirmOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out=response.getWriter();

        String orderNum = request.getParameter("orderNum");
        String status = request.getParameter("status");

        OrderOperation OrdOp = new OrderOperation();
        if ("运输中".equals(status)){
            OrdOp.CusConfirmOrder(orderNum);
            out.print("<script>alert('确认收货成功！');window.location.href='customerOrder.jsp'</script>");
        } else if ("退货中".equals(status)){
            out.print("<script>alert('此订单正在退货中，请勿做任何操作！');window.location.href='customerOrder.jsp'</script>");
        }else if ("已退货".equals(status)){
            out.print("<script>alert('此订单已退货，请勿做任何操作！');window.location.href='customerOrder.jsp'</script>");
        }else if ("已收货".equals(status)){
            out.print("<script>alert('此订单已结单，请勿做任何操作！');window.location.href='customerOrder.jsp'</script>");
        } else {
            out.print("<script>alert('订单正在处理中，请稍后再操作！');window.location.href='customerOrder.jsp'</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
