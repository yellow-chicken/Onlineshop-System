package com.jxnu.servlet;

import com.jxnu.service.CustomerOperation;
import com.jxnu.service.OrderOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class CusReturnGoodsServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out=response.getWriter();

        String username = (String)request.getSession().getAttribute("username");
        CustomerOperation CusOp = new CustomerOperation();
        double money = CusOp.getInformation(username).get(0).getMoney();

        String orderNum = request.getParameter("orderNum");
        String busName = request.getParameter("busName");
        String goodsName = request.getParameter("goodsName");
        Integer totalNum = Integer.valueOf(request.getParameter("totalNum"));
        double totalMoney = Double.valueOf(request.getParameter("totalMoney"));
        String companyName = request.getParameter("companyName");
        String status = request.getParameter("status");

        OrderOperation OrdOp = new OrderOperation();
        if ("已退货".equals(status) || "退货中".equals(status)){
            out.print("<script>alert('此订单已退货，请勿重复操作！');window.location.href='customerService.jsp'</script>");
        } else if ("已收货".equals(status) || "运输中".equals(status)){
            if (money - 10 >= 0){
                //消费者自付快递费
                OrdOp.CusUseMoney(username);
                OrdOp.CompanyGetMoney(companyName);
                //更改状态为"退货中"
                OrdOp.CusReturnGoods(orderNum);
                //退钱
                OrdOp.BusReturnMoney(busName,totalMoney);
                OrdOp.CusGetReturnMoney(username,totalMoney);
                //退货
                OrdOp.addReturnGoods(busName,goodsName,totalNum);
                out.print("<script>alert('退货成功，等待快递公司配送！');window.location.href='customerService.jsp'</script>");
            } else {
                out.print("<script>alert('余额不足,请前往充值！');window.location.href='customerRecharge.jsp'</script>");
            }
        } else if ("处理中".equals(status)){
            //"处理中" 直接退货 商家和消费者都不需要付快递费，因为此时商家还未选择快递公司即未付快递费
            //更改状态为"已退货"
            OrdOp.ComReturnGoods(orderNum);
            //退钱
            OrdOp.BusReturnMoney(busName,totalMoney);
            OrdOp.CusGetReturnMoney(username,totalMoney);
            //退货
            OrdOp.addReturnGoods(busName,goodsName,totalNum);
            out.print("<script>alert('退货成功！');window.location.href='customerService.jsp'</script>");
        } else if ("已出货".equals(status)){
            //"已出货" 直接退货 快递公司退快递费给商家，因为此时商家已付快递费但快递公司还未接单配送
            //快递公司退还快递费给商家
            OrdOp.ComUseMoney(companyName);
            OrdOp.BusGetMoney(busName);
            //更改状态为"已退货"
            OrdOp.ComReturnGoods(orderNum);
            //退钱
            OrdOp.BusReturnMoney(busName,totalMoney);
            OrdOp.CusGetReturnMoney(username,totalMoney);
            //退货
            OrdOp.addReturnGoods(busName,goodsName,totalNum);
            out.print("<script>alert('退货成功！');window.location.href='customerService.jsp'</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
