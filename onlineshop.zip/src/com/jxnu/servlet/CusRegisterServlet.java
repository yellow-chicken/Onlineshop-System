package com.jxnu.servlet;

import com.jxnu.bean.Customer;
import com.jxnu.bean.LoginInfo;
import com.jxnu.service.RegisterOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class CusRegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String identity = request.getParameter("identity");
        String name = request.getParameter("name");
        String sex = request.getParameter("sex");
        String tel = request.getParameter("tel");

        RegisterOperation regO = new RegisterOperation();
        if (!regO.isUnameExist(username)) {
            if (!regO.cusTelIsExist(tel) && !regO.busTelIsExist(tel) && !regO.comTelIsExist(tel)) {
                Customer customer = new Customer();

                customer.setUsername(username);
                customer.setName(name);
                customer.setSex(sex);
                customer.setTel(tel);
                regO.registerCustomer(customer);

                LoginInfo loginInfo = new LoginInfo();

                loginInfo.setUsername(username);
                loginInfo.setPassword(password);
                loginInfo.setIdentity(identity);

                regO.addTologin(loginInfo);
                out.print("<script>alert('注册成功！');window.location.href='index.jsp'</script>");
            } else {
                out.print("<script>alert('此号码已被注册！');window.location.href='registerCustomer.jsp'</script>");
            }
        } else{
            out.print("<script>alert('此用户名已被注册！');window.location.href='registerCustomer.jsp'</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
