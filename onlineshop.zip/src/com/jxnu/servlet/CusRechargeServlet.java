package com.jxnu.servlet;

import com.jxnu.service.CustomerOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class CusRechargeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out=response.getWriter();

        String username = (String)request.getSession().getAttribute("username");
        String charges=request.getParameter("charge");
        double charge=Double.valueOf(charges);
        CustomerOperation CusOp = new CustomerOperation();
        if (charge > 0) {
            CusOp.recharge(username,charge);
            out.print("<script>alert('恭喜您，充值成功！');window.location.href='customerRecharge.jsp'</script>");
        } else {
            out.print("<script>alert('充值金额需大于0！');window.location.href='customerRecharge.jsp'</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
