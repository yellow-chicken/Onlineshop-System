package com.jxnu.servlet;

import com.jxnu.service.BusinessOperation;
import com.jxnu.service.OrderOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class BusSendGoodsServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out=response.getWriter();

        String username = (String)request.getSession().getAttribute("username");
        BusinessOperation BusOp = new BusinessOperation();
        double money = BusOp.getInformation(username).get(0).getMoney();

        String orderNum = request.getParameter("orderNum");
        String status = request.getParameter("status");
        String comNames = request.getParameter("comNames");

        OrderOperation OrdOp = new OrderOperation();
        if ("处理中".equals(status)){
            if (money - 10 >= 0){
                OrdOp.BusUseMoney(username);
                OrdOp.BusSendGoods(orderNum);
                OrdOp.BusChooseCom(orderNum,comNames);
                OrdOp.CompanyGetMoney(comNames);
                out.print("<script>alert('发货成功！');window.location.href='businessOrderHandle.jsp'</script>");
            } else {
                out.print("<script>alert('余额不足，请前往充值！');window.location.href='businessRecharge.jsp'</script>");
            }
        } else if ("已退货".equals(status) || "退货中".equals(status)){
            out.print("<script>alert('此订单已退货，请勿做任何操作！');window.location.href='businessOrderHandle.jsp'</script>");
        }else {
            out.print("<script>alert('此订单已出货，请勿重复发货！');window.location.href='businessOrderHandle.jsp'</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
