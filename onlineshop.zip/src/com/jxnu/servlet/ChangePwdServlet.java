package com.jxnu.servlet;

import com.jxnu.service.PublicOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class ChangePwdServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out=response.getWriter();

        String originalPwd = request.getParameter("pwd0");
        String password = request.getParameter("pwd1");
        String username = (String)request.getSession().getAttribute("username");
        PublicOperation PubO = new PublicOperation();
        if (PubO.checkPwd(username,originalPwd)) {
            PubO.changePwd(username,password);
            out.print("<script>alert('修改密码成功，请重新登录！');window.location.href='index.jsp'</script>");
        } else {
            out.print("<script>alert('原密码输入错误，请重新输入！');window.history.go(-1)</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
