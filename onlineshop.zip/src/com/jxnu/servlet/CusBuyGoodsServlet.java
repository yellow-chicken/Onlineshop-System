package com.jxnu.servlet;

import com.jxnu.service.BusinessOperation;
import com.jxnu.service.CustomerOperation;
import com.jxnu.service.OrderOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class CusBuyGoodsServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out=response.getWriter();

        String username = (String)request.getSession().getAttribute("username");
        OrderOperation OrdOp = new OrderOperation();
        CustomerOperation CusOp = new CustomerOperation();
        BusinessOperation BusOp = new BusinessOperation();

        String orderNum = OrdOp.getOrderNum();//订单号
        String busName = request.getParameter("busName");//商家名
        String goodsName = request.getParameter("goodsName");//商品名
        Integer totalNum = Integer.valueOf(request.getParameter("totalNum"));//购买商品数量
        double goodsPrice = Double.valueOf(request.getParameter("goodsPrice"));//商品单价
        double totalMoney = goodsPrice * totalNum;//购买的总价
        double money = CusOp.getInformation(username).get(0).getMoney();//消费者余额
        String customerName = CusOp.getInformation(username).get(0).getName();//消费者姓名
        String tel = CusOp.getInformation(username).get(0).getTel();//消费者联系方式
        String busAddr = BusOp.getInformationByName(busName).get(0).getAddr();//商家地址
        String cusAddr = CusOp.getInformation(username).get(0).getAddr();//收货地址
        Integer goodsNum = Integer.valueOf(request.getParameter("goodsNum"));//商品库存

        if (!("".equals(cusAddr))){
            if (goodsNum - totalNum >= 0) {
                if (money - totalMoney >= 0) {
                    CusOp.useMoney(username,totalMoney);
                    OrdOp.earnMoney(busName,totalMoney);
                    CusOp.subtractGoodsNum(busName,goodsName,totalNum);
                    OrdOp.addToOrder(orderNum,busName,goodsName,totalNum,totalMoney,customerName,tel,busAddr,cusAddr);
                    out.print("<script>alert('下单成功！');window.history.go(-1);</script>");
                } else {
                    out.print("<script>alert('余额不足,请前往充值！');window.location.href='customerRecharge.jsp'</script>");
                }
            } else {
                out.print("<script>alert('商品库存不足！');window.history.go(-1);</script>");
            }
        } else {
            out.print("<script>alert('您尚未填写收货地址！');window.location.href='customerChangeAddr.jsp'</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
