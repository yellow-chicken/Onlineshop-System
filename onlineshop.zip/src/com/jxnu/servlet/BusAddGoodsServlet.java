package com.jxnu.servlet;

import com.jxnu.bean.Business;
import com.jxnu.service.BusinessOperation;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class BusAddGoodsServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out=response.getWriter();

        String username = (String)request.getSession().getAttribute("username");
        String busName = request.getParameter("busName");
        String goodsName = request.getParameter("goodsName");
        Integer goodsNum = Integer.valueOf(request.getParameter("goodsNum"));
        Integer goodsOriginalPrice = Integer.valueOf(request.getParameter("goodsOriginalPrice"));
        double totalMoney = goodsOriginalPrice * goodsNum;//进货的总价

        BusinessOperation BusOp = new BusinessOperation();
        List<Business> list = BusOp.getInformation(username);
        double money = list.get(0).getMoney();//商家的账户余额

        if (money - totalMoney >= 0) {
            //钱够
            BusOp.useMoney(username,totalMoney);
            BusOp.addGoods(busName,goodsName,goodsNum);
            out.print("<script>alert('进货成功！');window.location.href='businessShowGoods.jsp'</script>");
        } else {
            out.print("<script>alert('余额不足，请前往充值！');window.location.href='businessRecharge.jsp'</script>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
