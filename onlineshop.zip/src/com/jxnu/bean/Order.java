package com.jxnu.bean;

public class Order {
    private Integer id;
    private String orderNum;
    private String busName;
    private String goodsName;
    private Integer totalNum;
    private double totalMoney;
    private String customerName;
    private String tel;
    private String busAddr;
    private String cusAddr;
    private String companyName;
    private String status;

    public Order() {
    }

    public Order(Integer id, String orderNum, String busName, String goodsName, Integer totalNum, double totalMoney, String customerName, String tel, String busAddr, String cusAddr, String companyName, String status) {
        this.id = id;
        this.orderNum = orderNum;
        this.busName = busName;
        this.goodsName = goodsName;
        this.totalNum = totalNum;
        this.totalMoney = totalMoney;
        this.customerName = customerName;
        this.tel = tel;
        this.busAddr = busAddr;
        this.cusAddr = cusAddr;
        this.companyName = companyName;
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public String getBusName() {
        return busName;
    }

    public void setBusName(String busName) {
        this.busName = busName;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public Integer getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(Integer totalNum) {
        this.totalNum = totalNum;
    }

    public double getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(double totalMoney) {
        this.totalMoney = totalMoney;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getBusAddr() {
        return busAddr;
    }

    public void setBusAddr(String busAddr) {
        this.busAddr = busAddr;
    }

    public String getCusAddr() {
        return cusAddr;
    }

    public void setCusAddr(String cusAddr) {
        this.cusAddr = cusAddr;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", orderNum='" + orderNum + '\'' +
                ", busName='" + busName + '\'' +
                ", goodsName='" + goodsName + '\'' +
                ", totalNum=" + totalNum +
                ", totalMoney=" + totalMoney +
                ", customerName='" + customerName + '\'' +
                ", tel='" + tel + '\'' +
                ", busAddr='" + busAddr + '\'' +
                ", cusAddr='" + cusAddr + '\'' +
                ", companyName='" + companyName + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
