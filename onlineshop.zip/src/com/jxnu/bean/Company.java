package com.jxnu.bean;

public class Company {
    private Integer id;
    private String username;
    private String name;
    private String tel;
    private double money;

    public Company() {
    }

    public Company(Integer id, String username, String name, String tel, double money) {
        this.id = id;
        this.username = username;
        this.name = name;
        this.tel = tel;
        this.money = money;
    }

    public Integer getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getName() {
        return name;
    }

    public String getTel() {
        return tel;
    }

    public double getMoney() {
        return money;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    @Override
    public String toString() {
        return "Company{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", name='" + name + '\'' +
                ", tel='" + tel + '\'' +
                ", money=" + money +
                '}';
    }
}
