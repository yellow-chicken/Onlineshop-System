package com.jxnu.bean;

public class Business {
    private Integer id;
    private String username;
    private String name;
    private String addr;
    private String tel;
    private double money;

    public Business() {
    }

    public Business(Integer id, String username, String name, String addr, String tel, double money) {
        this.id = id;
        this.username = username;
        this.name = name;
        this.addr = addr;
        this.tel = tel;
        this.money = money;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public Integer getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getName() {
        return name;
    }

    public String getAddr() {
        return addr;
    }

    public String getTel() {
        return tel;
    }

    public double getMoney() {
        return money;
    }

    @Override
    public String toString() {
        return "Business{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", name='" + name + '\'' +
                ", addr='" + addr + '\'' +
                ", tel='" + tel + '\'' +
                ", money=" + money +
                '}';
    }
}
