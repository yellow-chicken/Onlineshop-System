package com.jxnu.bean;

public class Customer {
    private Integer id;
    private String username;
    private String name;
    private String sex;
    private String tel;
    private double money;
    private String addr;

    public Integer getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getName() {
        return name;
    }

    public String getSex() {
        return sex;
    }

    public String getTel() {
        return tel;
    }

    public double getMoney() {
        return money;
    }

    public String getAddr() {
        return addr;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public Customer() {
    }

    public Customer(Integer id, String username, String name, String sex, String tel, double money, String addr) {
        this.id = id;
        this.username = username;
        this.name = name;
        this.sex = sex;
        this.tel = tel;
        this.money = money;
        this.addr = addr;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", tel='" + tel + '\'' +
                ", money=" + money +
                ", addr='" + addr + '\'' +
                '}';
    }
}
