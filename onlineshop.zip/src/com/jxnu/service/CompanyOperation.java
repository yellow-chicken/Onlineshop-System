package com.jxnu.service;

import com.jxnu.bean.Company;
import com.jxnu.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CompanyOperation {
    public CompanyOperation() {
    }

    /**
     * 获取公司信息
     * @param username
     * @return
     */
    public List<Company> getInformation(String username){
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<Company> list = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select * from t_company where username = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,username);

            rs = ps.executeQuery();
            while (rs.next()) {
                Company company = new Company();
                company.setUsername(rs.getString("username"));
                company.setName(rs.getString("name"));
                company.setTel(rs.getString("tel"));
                company.setMoney(rs.getDouble("money"));
                list.add(company);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return list;
    }

    /**
     * 找回密码：验证填写的用户名和联系方式是否正确
     * @param username
     * @param tel
     * @return
     */
    public boolean checkUsernameTel(String username,String tel){
        boolean isTrue = false;
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        try {
            conn = JDBCUtils.getConnection();
            String sql = "select * from t_company where username = ? and  tel = ?";

            ps = conn.prepareStatement(sql);
            ps.setString(1,username);
            ps.setString(2,tel);
            rs = ps.executeQuery();
            if (rs.next()) {
                isTrue = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return isTrue;
    }

    /**
     * 获取所有快递公司的名字
     * @return
     */
    public List<Company> getCompanyName(){
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<Company> list = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select * from t_company";
            ps = conn.prepareStatement(sql);

            rs = ps.executeQuery();
            while (rs.next()) {
                Company company = new Company();
                company.setName(rs.getString("name"));
                list.add(company);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return list;
    }
}
