package com.jxnu.service;

import com.jxnu.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 三种角色的公共操作
 */
public class PublicOperation {
    public PublicOperation() {
    }

    /**
     * 检查原始密码是否正确
     * @param username
     * @param password
     * @return
     */
    public boolean checkPwd(String username,String password){
        boolean isTrue = false;
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        try {
            conn = JDBCUtils.getConnection();
            String sql = "select * from t_login where username = ?";

            ps = conn.prepareStatement(sql);
            ps.setString(1,username);
            rs = ps.executeQuery();
            if (rs.next()) {
                String pwd = rs.getString("password");
                if (pwd.equals(password)) {
                    isTrue = true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return isTrue;
    }

    /**
     * 修改密码
     * @param username
     */
    public void changePwd(String username,String password){
        Connection conn= null;
        PreparedStatement ps = null;

        try {
            conn = JDBCUtils.getConnection();
            String sql = "update t_login set password = ? where username = ?";

            ps = conn.prepareStatement(sql);
            ps.setString(1,password);
            ps.setString(2,username);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }
}
