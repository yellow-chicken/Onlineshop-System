package com.jxnu.service;

import com.jxnu.bean.Business;
import com.jxnu.bean.Goods;
import com.jxnu.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BusinessOperation {
    public BusinessOperation() {
    }

    /**
     * 获取商家信息
     * @param username
     * @return
     */
    public List<Business> getInformation(String username){
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<Business> list = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select * from t_business where username = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,username);

            rs = ps.executeQuery();
            while (rs.next()) {
                Business business = new Business();
                business.setUsername(rs.getString("username"));
                business.setName(rs.getString("name"));
                business.setAddr(rs.getString("addr"));
                business.setTel(rs.getString("tel"));
                business.setMoney(rs.getDouble("money"));
                list.add(business);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return list;
    }

    /**
     * 根据店铺名获取商家信息
     * @param name
     * @return
     */
    public List<Business> getInformationByName(String name){
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<Business> list = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select * from t_business where name = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,name);

            rs = ps.executeQuery();
            while (rs.next()) {
                Business business = new Business();
                business.setUsername(rs.getString("username"));
                business.setName(rs.getString("name"));
                business.setAddr(rs.getString("addr"));
                business.setTel(rs.getString("tel"));
                business.setMoney(rs.getDouble("money"));
                list.add(business);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return list;
    }

    /**
     * 商家充值
     * @param username
     * @param money
     */
    public void recharge(String username,double money){
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_business set money = money + ? where username = ?";
            ps = conn.prepareStatement(sql);

            ps.setDouble(1,money);
            ps.setString(2,username);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 找回密码：验证填写的用户名和联系方式是否正确
     * @param username
     * @param tel
     * @return
     */
    public boolean checkUsernameTel(String username,String tel){
        boolean isTrue = false;
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        try {
            conn = JDBCUtils.getConnection();
            String sql = "select * from t_business where username = ? and  tel = ?";

            ps = conn.prepareStatement(sql);
            ps.setString(1,username);
            ps.setString(2,tel);
            rs = ps.executeQuery();
            if (rs.next()) {
                isTrue = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return isTrue;
    }

    /**
     * 商家根据用户名查找店铺名称
     * @param username
     * @return
     */
    public String getBusinessName(String username) {
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        String busName = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select name from t_business where username = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,username);

            rs = ps.executeQuery();
            while (rs.next()) {
                busName = rs.getString("name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return busName;
    }

    /**
     * 获取商家的所有商品名字
     * @param busName
     * @return
     */
    public List<String> getGoodsName(String busName) {
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<String> nameList = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select goodsName from t_goods where busName = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,busName);

            rs = ps.executeQuery();
            while (rs.next()) {
                nameList.add(rs.getString("goodsName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return nameList;
    }

    /**
     * 获取商家此商品的信息
     * @param busName
     * @param goodsName
     * @return
     */
    public List<Goods> getGoodsInformation(String busName,String goodsName) {
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<Goods> list = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select * from t_goods where busName = ? and goodsName = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,busName);
            ps.setString(2,goodsName);

            rs = ps.executeQuery();

            while (rs.next()) {
                Goods goods = new Goods();
                goods.setBusName(rs.getString("busName"));
                goods.setGoodsName(rs.getString("goodsName"));
                goods.setGoodsPrice(rs.getDouble("goodsPrice"));
                goods.setGoodsNum(rs.getInt("goodsNum"));
                goods.setGoodsOriginalPrice(rs.getDouble("goodsOriginalPrice"));
                goods.setType(rs.getString("type"));
                list.add(goods);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return list;
    }

    /**
     * 商家进货:买货
     * @param username
     * @param totalMoney
     */
    public void useMoney(String username,double totalMoney){
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_business set money = money - ? where username = ?";
            ps = conn.prepareStatement(sql);

            ps.setDouble(1,totalMoney);
            ps.setString(2,username);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 商家进货:加货
     * @param busName
     * @param goodsName
     * @param goodsNum
     */
    public void addGoods(String busName,String goodsName,Integer goodsNum){
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_goods set goodsNum = goodsNum + ? where goodsName = ? and busName = ?";
            ps = conn.prepareStatement(sql);

            ps.setInt(1,goodsNum);
            ps.setString(2,goodsName);
            ps.setString(3,busName);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 根据商品类型获取商品信息
     * @param type
     * @return
     */
    public List<Goods> getGoodsInformation(String type) {
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<Goods> list = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select * from t_goods where type = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,type);

            rs = ps.executeQuery();

            while (rs.next()) {
                Goods goods = new Goods();
                goods.setBusName(rs.getString("busName"));
                goods.setGoodsName(rs.getString("goodsName"));
                goods.setGoodsPrice(rs.getDouble("goodsPrice"));
                goods.setGoodsNum(rs.getInt("goodsNum"));
                goods.setType(rs.getString("type"));
                list.add(goods);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return list;
    }
}
