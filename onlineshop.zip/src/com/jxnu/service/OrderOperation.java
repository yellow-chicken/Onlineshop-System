package com.jxnu.service;

import com.jxnu.bean.Order;
import com.jxnu.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrderOperation {
    public OrderOperation() {
    }

    /**
     * 根据电话号码获取指定消费者的订单信息
     * @param tel
     * @return
     */
    public List<Order> getInformation(String tel){
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<Order> list = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select * from t_order where tel = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,tel);

            rs = ps.executeQuery();
            while (rs.next()) {
                Order order = new Order();
                order.setOrderNum(rs.getString("orderNum"));
                order.setBusName(rs.getString("busName"));
                order.setGoodsName(rs.getString("goodsName"));
                order.setTotalNum(rs.getInt("totalNum"));
                order.setTotalMoney(rs.getDouble("totalMoney"));
                order.setCustomerName(rs.getString("customerName"));
                order.setTel(rs.getString("tel"));
                order.setBusAddr(rs.getString("busAddr"));
                order.setCusAddr(rs.getString("cusAddr"));
                order.setCompanyName(rs.getString("companyName"));
                order.setStatus(rs.getString("status"));

                list.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return list;
    }

    /**
     * 根据商家名称获取其订单信息
     * @param busName
     * @return
     */
    public List<Order> getInformationByBusName(String busName){
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<Order> list = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select * from t_order where busName = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,busName);

            rs = ps.executeQuery();
            while (rs.next()) {
                Order order = new Order();
                order.setOrderNum(rs.getString("orderNum"));
                order.setBusName(rs.getString("busName"));
                order.setGoodsName(rs.getString("goodsName"));
                order.setTotalNum(rs.getInt("totalNum"));
                order.setTotalMoney(rs.getDouble("totalMoney"));
                order.setCustomerName(rs.getString("customerName"));
                order.setTel(rs.getString("tel"));
                order.setBusAddr(rs.getString("busAddr"));
                order.setCusAddr(rs.getString("cusAddr"));
                order.setCompanyName(rs.getString("companyName"));
                order.setStatus(rs.getString("status"));

                list.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return list;
    }

    /**
     * 根据快递公司名获取其公司的订单信息
     * @param companyName
     * @return
     */
    public List<Order> getInformationByComName(String companyName){
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<Order> list = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select * from t_order where companyName = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,companyName);

            rs = ps.executeQuery();
            while (rs.next()) {
                Order order = new Order();
                order.setOrderNum(rs.getString("orderNum"));
                order.setBusName(rs.getString("busName"));
                order.setGoodsName(rs.getString("goodsName"));
                order.setTotalNum(rs.getInt("totalNum"));
                order.setTotalMoney(rs.getDouble("totalMoney"));
                order.setCustomerName(rs.getString("customerName"));
                order.setTel(rs.getString("tel"));
                order.setBusAddr(rs.getString("busAddr"));
                order.setCusAddr(rs.getString("cusAddr"));
                order.setStatus(rs.getString("status"));

                list.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return list;
    }

    /**
     * 根据下单时间生成订单号
     * @return
     */
    public String getOrderNum(){
        Date nowTime = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        return sdf.format(nowTime);
    }

    /**
     * 消费者下单：初始化订单表1
     * @param orderNum
     * @param busName
     * @param goodsName
     * @param totalNum
     * @param totalMoney
     * @param customerName
     * @param tel
     * @param busAddr
     * @param cusAddr
     */
    public void addToOrder(String orderNum,String busName,String goodsName,Integer totalNum,double totalMoney,String customerName,String tel,String busAddr,String cusAddr){
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="insert into t_order(orderNum,busName,goodsName,totalNum,totalMoney,customerName,tel,busAddr,cusAddr,status) values(?,?,?,?,?,?,?,?,?,?)";
            ps = conn.prepareStatement(sql);

            ps.setString(1,orderNum);
            ps.setString(2,busName);
            ps.setString(3,goodsName);
            ps.setInt(4,totalNum);
            ps.setDouble(5,totalMoney);
            ps.setString(6,customerName);
            ps.setString(7,tel);
            ps.setString(8,busAddr);
            ps.setString(9,cusAddr);
            ps.setString(10,"处理中");

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 消费者下单：商家收款
     * @param busName
     * @param totalMoney
     */
    public void earnMoney(String busName,double totalMoney) {
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_business set money = money + ? where name = ?";
            ps = conn.prepareStatement(sql);

            ps.setDouble(1,totalMoney);
            ps.setString(2,busName);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 商家发货：选择快递公司
     * @param orderNum
     * @param companyName
     */
    public void BusChooseCom(String orderNum,String companyName) {
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_order set companyName = ? where orderNum = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,companyName);
            ps.setString(2,orderNum);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 商家发货：付快递费
     * @param username
     */
    public void BusUseMoney(String username) {
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_business set money = money - ? where username = ?";
            ps = conn.prepareStatement(sql);

            ps.setDouble(1,10.00);
            ps.setString(2,username);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 商家发货(或者退货操作)：快递公司得到收益
     * @param companyName
     */
    public void CompanyGetMoney(String companyName) {
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_company set money = money + ? where name = ?";
            ps = conn.prepareStatement(sql);

            ps.setDouble(1,10.00);
            ps.setString(2,companyName);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 商家发货：更改订单状态
     * @param orderNum
     */
    public void BusSendGoods(String orderNum) {
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_order set status = ? where orderNum = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,"已出货");
            ps.setString(2,orderNum);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 快递公司配送：更改订单状态
     * @param orderNum
     */
    public void ComSendGoods(String orderNum) {
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_order set status = ? where orderNum = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,"运输中");
            ps.setString(2,orderNum);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 消费者确认收货：更改订单状态
     * @param orderNum
     */
    public void CusConfirmOrder(String orderNum) {
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_order set status = ? where orderNum = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,"已收货");
            ps.setString(2,orderNum);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }


    /**
     * 消费者退货："已收货" 或 "运输中" 消费者自付快递费
     * @param username
     */
    public void CusUseMoney(String username) {
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_customer set money = money - ? where username = ?";
            ps = conn.prepareStatement(sql);

            ps.setDouble(1,10.00);
            ps.setString(2,username);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 消费者退货：更改订单状态为退货中 等待快递公司接单
     * @param orderNum
     */
    public void CusReturnGoods(String orderNum) {
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_order set status = ? where orderNum = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,"退货中");
            ps.setString(2,orderNum);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 消费者退货：快递公司配送 更改订单状态
     * @param orderNum
     */
    public void ComReturnGoods(String orderNum) {
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_order set status = ? where orderNum = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,"已退货");
            ps.setString(2,orderNum);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 消费者退货：商家退还资金
     * @param busName
     * @param totalMoney
     */
    public void BusReturnMoney(String busName,double totalMoney){
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_business set money = money - ? where name = ?";
            ps = conn.prepareStatement(sql);

            ps.setDouble(1,totalMoney);
            ps.setString(2,busName);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 消费者退货：消费者得到退还资金
     * @param username
     * @param totalMoney
     */
    public void CusGetReturnMoney(String username,double totalMoney){
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_customer set money = money + ? where username = ?";
            ps = conn.prepareStatement(sql);

            ps.setDouble(1,totalMoney);
            ps.setString(2,username);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 消费者退货：退货商品回到商家库存中
     * @param busName
     * @param goodsName
     * @param totalNum
     */
    public void addReturnGoods(String busName,String goodsName,Integer totalNum){
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_goods set goodsNum = goodsNum + ? where goodsName = ? and busName = ?";
            ps = conn.prepareStatement(sql);

            ps.setInt(1,totalNum);
            ps.setString(2,goodsName);
            ps.setString(3,busName);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 消费者退货："已出货" 快递公司退快递费给商家
     * @param companyName
     */
    public void ComUseMoney(String companyName) {
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_company set money = money - ? where name = ?";
            ps = conn.prepareStatement(sql);

            ps.setDouble(1,10.00);
            ps.setString(2,companyName);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 消费者退货："已出货" 商家得到快递公司退还的快递费
     * @param busName
     */
    public void BusGetMoney(String busName) {
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_business set money = money + ? where name = ?";
            ps = conn.prepareStatement(sql);

            ps.setDouble(1,10.00);
            ps.setString(2,busName);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 显示商家收益订单表（不包含退货中和已退货的订单）
     * @param busName
     * @return
     */
    public List<Order> getBusIncomeOrder(String busName){
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<Order> list = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select * from t_order where busName = ? and status not in (?,?)";
            ps = conn.prepareStatement(sql);

            ps.setString(1,busName);
            ps.setString(2,"退货中");
            ps.setString(3,"已退货");

            rs = ps.executeQuery();
            while (rs.next()) {
                Order order = new Order();
                order.setOrderNum(rs.getString("orderNum"));
                order.setBusName(rs.getString("busName"));
                order.setGoodsName(rs.getString("goodsName"));
                order.setTotalNum(rs.getInt("totalNum"));
                order.setTotalMoney(rs.getDouble("totalMoney"));
                order.setCustomerName(rs.getString("customerName"));
                order.setTel(rs.getString("tel"));
                order.setCompanyName(rs.getString("companyName"));
                order.setStatus(rs.getString("status"));

                list.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return list;
    }

    /**
     * 显示快递公司订单表（不包含退货中和已退货的订单）
     * @param companyName
     * @return
     */
    public List<Order> getComIncomeOrder(String companyName){
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<Order> list = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select * from t_order where companyName = ? and status not in (?,?)";
            ps = conn.prepareStatement(sql);

            ps.setString(1,companyName);
            ps.setString(2,"退货中");
            ps.setString(3,"已退货");

            rs = ps.executeQuery();
            while (rs.next()) {
                Order order = new Order();
                order.setOrderNum(rs.getString("orderNum"));
                order.setBusName(rs.getString("busName"));
                order.setGoodsName(rs.getString("goodsName"));
                order.setTotalNum(rs.getInt("totalNum"));
                order.setTotalMoney(rs.getDouble("totalMoney"));
                order.setCustomerName(rs.getString("customerName"));
                order.setTel(rs.getString("tel"));
                order.setCompanyName(rs.getString("companyName"));
                order.setStatus(rs.getString("status"));

                list.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return list;
    }
}
