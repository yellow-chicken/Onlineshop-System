package com.jxnu.service;

import com.jxnu.bean.Customer;
import com.jxnu.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerOperation {
    public CustomerOperation() {
    }

    /**
     * 获取个人信息
     * @param username
     * @return
     */
    public List<Customer> getInformation(String username){
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        List<Customer> list = new ArrayList<>();
        try {
            conn = JDBCUtils.getConnection();
            String sql ="select * from t_customer where username = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,username);

            rs = ps.executeQuery();
            while (rs.next()) {
                Customer customer = new Customer();
                customer.setUsername(rs.getString("username"));
                customer.setName(rs.getString("name"));
                customer.setSex(rs.getString("sex"));
                customer.setTel(rs.getString("tel"));
                customer.setAddr(rs.getString("addr"));
                customer.setMoney(rs.getDouble("money"));
                list.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return list;
    }

    /**
     * 消费者充值
     * @param username
     * @param money
     */
    public void recharge(String username,double money){
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_customer set money = money + ? where username = ?";
            ps = conn.prepareStatement(sql);

            ps.setDouble(1,money);
            ps.setString(2,username);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 设置（修改）收货地址
     * @param username
     * @param addr
     */
    public void changeAddr(String username,String addr){
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_customer set addr = ? where username = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1,addr);
            ps.setString(2,username);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 找回密码：验证填写的用户名和联系方式是否正确
     * @param username
     * @param tel
     * @return
     */
    public boolean checkUsernameTel(String username,String tel){
        boolean isTrue = false;
        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;
        try {
            conn = JDBCUtils.getConnection();
            String sql = "select * from t_customer where username = ? and  tel = ?";

            ps = conn.prepareStatement(sql);
            ps.setString(1,username);
            ps.setString(2,tel);
            rs = ps.executeQuery();
            if (rs.next()) {
                isTrue = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return isTrue;
    }

    /**
     * 消费者购买商品：消费
     * @param username
     * @param totalMoney
     */
    public void useMoney(String username,double totalMoney){
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_customer set money = money - ? where username = ?";
            ps = conn.prepareStatement(sql);

            ps.setDouble(1,totalMoney);
            ps.setString(2,username);

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 消费者购买商品：减少库存
     * @param busName
     * @param goodsName
     * @param buyNum
     */
    public void subtractGoodsNum(String busName,String goodsName,Integer buyNum){
        Connection conn= null;
        PreparedStatement ps = null;
        try {
            conn = JDBCUtils.getConnection();
            String sql ="update t_goods set goodsNum = goodsNum - ? where goodsName = ? and busName = ?";
            ps = conn.prepareStatement(sql);

            ps.setInt(1,buyNum);
            ps.setString(2,goodsName);
            ps.setString(3,busName);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }
}
