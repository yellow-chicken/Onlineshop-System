package com.jxnu.service;

import com.jxnu.bean.Business;
import com.jxnu.bean.Company;
import com.jxnu.bean.Customer;
import com.jxnu.bean.LoginInfo;
import com.jxnu.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RegisterOperation {
    public RegisterOperation() {
    }

    /**
     * customer是否存在该tel
     * @param tel
     * @return
     */
    public boolean cusTelIsExist(String tel) {
        boolean telExist = false;

        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "select * from t_customer where tel = ?";

            ps = conn.prepareStatement(sql);
            ps.setString(1,tel);

            rs = ps.executeQuery();
            if (rs.next()) {
                telExist = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return telExist;
    }

    /**
     * business是否存在该tel
     * @param tel
     * @return
     */
    public boolean busTelIsExist(String tel) {
        boolean telExist = false;

        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "select * from t_business where tel = ?";

            ps = conn.prepareStatement(sql);
            ps.setString(1,tel);

            rs = ps.executeQuery();
            if (rs.next()) {
                telExist = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return telExist;
    }


    /**
     * company是否存在该tel
     * @param tel
     * @return
     */
    public boolean comTelIsExist(String tel) {
        boolean telExist = false;

        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "select * from t_company where tel = ?";

            ps = conn.prepareStatement(sql);
            ps.setString(1,tel);

            rs = ps.executeQuery();
            if (rs.next()) {
                telExist = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return telExist;
    }

    /**
     * 是否存在该用户名
     * @param username
     * @return
     */
    public boolean isUnameExist(String username) {
        boolean unameExist = false;

        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "select * from t_login where username = ?";

            ps = conn.prepareStatement(sql);
            ps.setString(1,username);

            rs = ps.executeQuery();
            if (rs.next()) {
                unameExist = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return unameExist;
    }

    /**
     * 是否存在该店铺名
     * @param name
     * @return
     */
    public boolean busNameIsExist(String name) {
        boolean nameExist = false;

        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "select * from t_business where name = ?";

            ps = conn.prepareStatement(sql);
            ps.setString(1,name);

            rs = ps.executeQuery();
            if (rs.next()) {
                nameExist = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return nameExist;
    }

    public boolean comNameIsExist(String name) {
        boolean nameExist = false;

        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "select * from t_company where name = ?";

            ps = conn.prepareStatement(sql);
            ps.setString(1,name);

            rs = ps.executeQuery();
            if (rs.next()) {
                nameExist = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return nameExist;
    }

    /**
     * 消费者注册
     * @param customer
     */
    public void registerCustomer(Customer customer) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "insert into t_customer(username, name, sex, tel) values(?,?,?,?)  ";
            ps = conn.prepareStatement(sql);

            ps.setString(1,customer.getUsername());
            ps.setString(2,customer.getName());
            ps.setString(3,customer.getSex());
            ps.setString(4,customer.getTel());

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 商家注册
     * @param business
     */
    public void registerBusiness(Business business) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "insert into t_business(username, name, tel, addr) values(?,?,?,?)  ";
            ps = conn.prepareStatement(sql);

            ps.setString(1,business.getUsername());
            ps.setString(2,business.getName());
            ps.setString(3,business.getTel());
            ps.setString(4,business.getAddr());

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 快递公司注册
     * @param company
     */
    public void registerCompany(Company company) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "insert into t_company(username, name, tel) values(?,?,?)  ";
            ps = conn.prepareStatement(sql);

            ps.setString(1,company.getUsername());
            ps.setString(2,company.getName());
            ps.setString(3,company.getTel());

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }

    /**
     * 将登录信息添加到t_login表中
     * @param loginInfo
     */
    public void addTologin(LoginInfo loginInfo) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = JDBCUtils.getConnection();

            String sql = "insert into t_login(username, password, identity) values(?,?,?)  ";
            ps = conn.prepareStatement(sql);

            ps.setString(1,loginInfo.getUsername());
            ps.setString(2,loginInfo.getPassword());
            ps.setString(3,loginInfo.getIdentity());

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,null);
        }
    }
}
