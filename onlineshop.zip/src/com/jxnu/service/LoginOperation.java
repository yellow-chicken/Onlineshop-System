package com.jxnu.service;

import com.jxnu.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginOperation {
    public LoginOperation() {
    }

    /**
     * 用户登录：验证用户名&密码
     * @param username
     * @param password
     * @return
     */
    public boolean login(String username, String password, String identity) {
        boolean loginInfo = false;

        Connection conn= null;
        PreparedStatement ps = null;
        ResultSet rs= null;

        try {
            //获取连接
            conn = JDBCUtils.getConnection();

            //获取数据库操作对象
            String sql ="select * from t_login where username = ? and password = ? and identity = ?";
            //预处理
            ps = conn.prepareStatement(sql);
            //给占位符传值
            ps.setString(1,username);
            ps.setString(2,password);
            ps.setString(3,identity);

            //处理结果集
            rs = ps.executeQuery();
            if (rs.next()) {
                //登录成功
                loginInfo = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtils.close(conn,ps,rs);
        }
        return loginInfo;
    }
}
